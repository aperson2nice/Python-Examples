#Sheila Robles
#Assignment 1 Problem 5
#Python Version 3.0.1

message = input("Please enter the message: ")
key = int(input("Please enter the key: ")) + 1

print(message[::key])