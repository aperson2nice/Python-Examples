#Sheila Robles
#Assignment 1 Problem 2
#Python Version 3.0.1

start = int(input("Enter a start value: "))
print("exp  res")
print("1   ",start ** 1)
print("2   ",start ** 2)
print("3   ",start ** 3)
print("4   ",start ** 4)