#Sheila Robles
#Assignment 1 Problem 3
#Python Version 3.0.1

names = input("Enter three names: ").split()
print(names[2])
print(names[1])
print(names[0])
