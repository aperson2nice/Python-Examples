#Sheila Robles
#Assignment 1 Problem 1
#Python Version 3.0.1

from math import pi

radius = int(input("Please enter the radius the circle: "))
area = radius*radius*pi
print("The area of a circle with radius",str(radius),"is: ",str(area))