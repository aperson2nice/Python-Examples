#Sheila Robles
#Assignment 4 Problem 3
#Python Version 3.0.1

from __future__ import print_function
import argparse as arg
import os
import zipfile

parser = arg.ArgumentParser(description='Zips or extracts files in a new zip or current working directory')

parser.add_argument('ARCHIVEFILE', help='The name of the zip file')
parser.add_argument('-f', '--files', nargs="*", help='A list of files to put in the archive file')
parser.add_argument('-x', '--extract', help='Extract the archive file. Set to True if wanting to extract')
parser.add_argument('-w', '--working-directory', help='Create a working directory in which everything will be saved to.')

# I need to check if ARCHIVEFILE is a zipfile, if not I have to give an error or make it a zip
arguments = parser.parse_args()
filepath = arguments.ARCHIVEFILE
list_of_files = arguments.files
toextract = arguments.extract
working_dir = arguments.working_directory


def compress(filepath, mode):
    new_zip = zipfile.ZipFile(filepath, mode)
    for f in list_of_files: #add files to working directory
        if not os.path.exists(f):
            print("ERROR: " + f + " does not exist.\n")
        elif f in new_zip.namelist():
            print("File " + f + " not transfered, already in zip file")
        else:
            new_zip.write(f)
    new_zip.close()
    
def start_compress(filepath):
    if os.path.exists(filepath):
        compress(filepath, 'a')
    else:
        compress(filepath, 'w')
            
def can_compress(filepath):
    if filepath[-4:len(filepath)] == ".zip":
        start_compress(filepath)
    else:
        print("Could not compress, not a valid path")

def check_wd(working_dir, filepath):
    if working_dir == None:
        can_compress(filepath)
    elif os.path.exists(working_dir) and working_dir[-1:len(working_dir)] == "\\":
        can_compress(working_dir+filepath)
    else: 
        print("Invalid directory:" + working_dir+filepath)
        
def extract(filepath,directory):
    if directory == None: directory = ".\\"
    if os.path.exists(directory+filepath):
        new_zip = zipfile.ZipFile(directory+filepath, 'r')
        new_zip.extractall(directory+filepath[:-4])
        new_zip.close()
    else:
        print("Invalid directory:" + directory + filepath)

#----------------------------------------------------

if bool(toextract) == True:
    extract(filepath, working_dir)
else:
    check_wd(working_dir, filepath)

#print the information of the archive file use writing zipinfo instance on zipfile page
new_zip = zipfile.ZipFile(filepath, 'r')
new_zip.printdir()
new_zip.close()


