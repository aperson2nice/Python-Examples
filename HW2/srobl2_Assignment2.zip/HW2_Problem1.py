#Sheila Robles
#Assignment 2 Problem 1
#Python Version 3.0.1

letter_frequency = {}
text = ""

f_or_d = input("File or direct: ")

if(f_or_d == "File" or f_or_d == "file"):
	#Open the file and read
	file_name = input("File name:") 
	read_file = open(file_name, "r")
	text = read_file.read()
	read_file.close()
else:
	#Read the line of text inputted
	text = input("Text: ")

for character in text:
	if character not in letter_frequency:
		letter_frequency[character] = 0
	letter_frequency[character] += 1
		
print(text)
print(letter_frequency)

input("Press ENTER to continue.") # wait before ending the program