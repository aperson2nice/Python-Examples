#Sheila Robles
#Assignment 2 Problem 2
#Python Version 3.0.1

w = int(input("Width: "))
h = int(input("Height: "))
default_char = input("Initial Character: ")

if len(default_char) != 1:
	print("None")
else:
	game_world = []
	for height in range(h):
		game_world.append([])
		for width in range(w):
			game_world[height].append(default_char)

print(game_world)

input("Press ENTER to continue.") # wait before ending the program